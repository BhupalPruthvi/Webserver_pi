


/************PROCESS DATA TO/FROM Client****************************/

	
var socket = io(); //load socket.io-client and connect to the host that serves the page
window.addEventListener("load", function(){ //when page loads
  if( isMobile.any() ) {
//    alert('Mobile');  
    document.addEventListener("touchstart", ReportTouchStart, false);
    document.addEventListener("touchend", ReportTouchEnd, false);
    document.addEventListener("touchmove", TouchMove, false);
  }else{
//    alert('Desktop');  
    document.addEventListener("mouseup", ReportMouseUp, false);
    document.addEventListener("mousedown", ReportMouseDown, false);
  }
  
});



//------------------RS_2---------------------------
//Update gpio feedback when server changes LED state
socket.on('GPIO26', function (data) {  
//  console.log('GPIO26 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
//  console.log(myJSON);
  document.getElementById('GPIO26').checked = data;
//  console.log('GPIO26: '+data.toString());
});

//------------------RS_3---------------------------
//Update gpio feedback when server changes LED state
socket.on('GPIO3', function (data) {  
  //  console.log('GPIO2 function called');
  //  console.log(data);
    var myJSON = JSON.stringify(data);
  //  console.log(myJSON);
    document.getElementById('GPIO3').checked = data;
  //  console.log('GPIO2: '+data.toString());
  });
  
/*
//Update gpio feedback when server changes LED state
socket.on('GPIO19', function (data) {  
//  console.log('GPIO19 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
 // console.log(myJSON);
  document.getElementById('GPIO19').checked = data;
//  console.log('GPIO19: '+data.toString());
});

//------------------RS_1---------------------------
//Update gpio feedback when server changes LED state
socket.on('GPIO20', function (data) {  
  console.log('GPIO20 function called');
  console.log(data);
  var myJSON = JSON.stringify(data);
  console.log(myJSON);
  document.getElementById('GPIO20').checked = data;
  console.log('GPIO20: '+data.toString());
});

//Update gpio feedback when server changes LED state
socket.on('GPIO21', function (data) {  
//  console.log('GPIO21 function called');
 // console.log(data);
  var myJSON = JSON.stringify(data);
 // console.log(myJSON);
  document.getElementById('GPIO21').checked = data;
// console.log('GPIO21: '+data.toString());
});

//Update gpio feedback when server changes LED state
socket.on('GPIO3', function (data) {  
//  console.log('GPIO3 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
//  console.log(myJSON);
  document.getElementById('GPIO3').checked = data;
//  console.log('GPIO3: '+data.toString());
});


//------------------RS_4---------------------------
//Update gpio feedback when server changes LED state
socket.on('GPIO17', function (data) {  
//  console.log('GPIO17 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
//  console.log(myJSON);
  document.getElementById('GPIO17').checked = data;
//  console.log('GPIO17: '+data.toString());
});

//Update gpio feedback when server changes LED state
socket.on('GPIO27', function (data) {  
//  console.log('GPIO27 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
//  console.log(myJSON);
  document.getElementById('GPIO27').checked = data;
//  console.log('GPIO27: '+data.toString());
});

//------------------RS_5---------------------------
//Update gpio feedback when server changes LED state
socket.on('GPIO23', function (data) {  
//  console.log('GPIO23 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
//  console.log(myJSON);
  document.getElementById('GPIO23').checked = data;
//  console.log('GPIO23: '+data.toString());
});

//Update gpio feedback when server changes LED state
socket.on('GPIO24', function (data) {  
//  console.log('GPIO24 function called');
//  console.log(data);
  var myJSON = JSON.stringify(data);
//  console.log(myJSON);
  document.getElementById('GPIO24').checked = data;
//  console.log('GPIO24: '+data.toString());
});

*/

function ReportTouchStart(e) {
  var y = e.target.previousElementSibling;
  if (y !== null) var x = y.id;
  if (x !== null) { 
  // Now we know that x is defined, we are good to go.
    if (x === "GPIO26") {
 //     console.log("GPIO26 toggle");
      socket.emit("GPIO26T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO20") {
      console.log("GPIO20 toggle");
      socket.emit("GPIO20T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO21") {
//      console.log("GPIO21 toggle");
      socket.emit("GPIO21T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO19") {
  //    console.log("GPIO19 toggle");
      socket.emit("GPIO19T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO24") {
  //    console.log("GPIO24 toggle");
      socket.emit("GPIO24T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO23") {
  //    console.log("GPIO23 toggle");
      socket.emit("GPIO23T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO2") {
  //    console.log("GPIO2 toggle");
      socket.emit("GPIO2T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO3") {
  //    console.log("GPIO3 toggle");
      socket.emit("GPIO3T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO17") {
  //    console.log("GPIO17 toggle");
      socket.emit("GPIO17T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO27") {
  //    console.log("GPIO27 toggle");
      socket.emit("GPIO27T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO7") {
  //    console.log("GPIO7 toggle");
      socket.emit("GPIO7T");  // send GPIO button toggle to node.js server
    } else if (x === "GPIO8") {
  //    console.log("GPIO8 toggle");
      socket.emit("GPIO8T");  // send GPIO button toggle to node.js server
    } 
  }

  if (e.target.id === "GPIO26M") {
    socket.emit("GPIO26", 0); 
    document.getElementById('GPIO26').checked = 0;
    
  } else if (e.target.id === "GPIO20M") {
    console.log("GPIO20 pressed");
    socket.emit("GPIO20", 0); 
    document.getElementById('GPIO20').checked = 0;
    
  } else if (e.target.id === "GPIO21M") {
  //  console.log("GPIO21 pressed");
    socket.emit("GPIO21", 0); 
    document.getElementById('GPIO21').checked = 0;
    
  } else if (e.target.id === "GPIO19M") {
//    console.log("GPIO19 pressed");
    socket.emit("GPIO19", 0); 
    document.getElementById('GPIO19').checked = 0;
    
  } else if (e.target.id === "GPIO2M") {
 //   console.log("GPIO2 pressed");
    socket.emit("GPIO2", 0); 
    document.getElementById('GPIO2').checked = 0;
    
  } else if (e.target.id === "GPIO3M") {
  //  console.log("GPIO3 pressed");
    socket.emit("GPIO3", 0); 
    document.getElementById('GPIO3').checked = 0;
    
  } else if (e.target.id === "GPIO17M") {
//    console.log("GPIO17 pressed");
    socket.emit("GPIO17", 0); 
    document.getElementById('GPIO17').checked = 0;
    
  } else if (e.target.id === "GPIO27M") {
 //   console.log("GPIO27 pressed");
    socket.emit("GPIO27", 0); 
    document.getElementById('GPIO27').checked = 0;
    
  } else if (e.target.id === "GPIO23M") {
  //  console.log("GPIO23 pressed");
    socket.emit("GPIO23", 0); 
    document.getElementById('GPIO32').checked = 0;
    
  } else if (e.target.id === "GPIO24M") {
//    console.log("GPIO24 pressed");
    socket.emit("GPIO24", 0); 
    document.getElementById('GPIO24').checked = 0;
  } else if (e.target.id === "GPIO7M") {
//    console.log("GPIO7 pressed");
    socket.emit("GPIO7", 0); 
    document.getElementById('GPIO7').checked = 0;
  } else if (e.target.id === "GPIO8M") {
//    console.log("GPIO8 pressed");
    socket.emit("GPIO8", 0); 
    document.getElementById('GPIO8').checked = 0;
  }
}

function ReportTouchEnd(e) {
  if (e.target.id === "GPIO26M") {
    socket.emit("GPIO26", 1); 
    document.getElementById('GPIO26').checked = 1;
    
  } else if (e.target.id === "GPIO20M") {
    socket.emit("GPIO20", 1); 
    document.getElementById('GPIO20').checked = 1;
    
  } else if (e.target.id === "GPIO21M") {
    socket.emit("GPIO21", 1); 
    document.getElementById('GPIO21').checked = 1;
    
  } else if (e.target.id === "GPIO19M") {
    socket.emit("GPIO19", 1); 
    document.getElementById('GPIO19').checked = 1;
    
  } else if (e.target.id === "GPIO2M") {
    socket.emit("GPIO2", 1); 
    document.getElementById('GPIO2').checked = 1;
    
  } else if (e.target.id === "GPIO3M") {
    socket.emit("GPIO3", 1); 
    document.getElementById('GPIO3').checked = 1;
    
  } else if (e.target.id === "GPIO17M") {
    socket.emit("GPIO17", 1); 
    document.getElementById('GPIO17').checked = 1;
    
  } else if (e.target.id === "GPIO27M") {
    socket.emit("GPIO27", 1); 
    document.getElementById('GPIO27').checked = 1;
    
  } else if (e.target.id === "GPIO23M") {
    socket.emit("GPIO23", 1); 
    document.getElementById('GPIO23').checked = 1;
    
  } else if (e.target.id === "GPIO24M") {
    socket.emit("GPIO24", 1); 
    document.getElementById('GPIO24').checked = 1;
  
  } else if (e.target.id === "GPIO7M") {
    socket.emit("GPIO7", 1); 
    document.getElementById('GPIO7').checked = 1;
  
  } else if (e.target.id === "GPIO8M") {
    socket.emit("GPIO8", 1); 
    document.getElementById('GPIO8').checked = 1;
  }
}

function ReportMouseDown(e) {
  
  var y = e.target.previousElementSibling;
  if (y !== null) var x = y.id;
  if (x !== null) { 
  // Now we know that x is defined, we are good to go.
    if (x === "GPIO26") {
 //     console.log("GPIO26 toggle");
      socket.emit("GPIO26T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO20") {
      console.log("GPIO20 toggle");
      socket.emit("GPIO20T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO21") {
 //     console.log("GPIO21 toggle");
      socket.emit("GPIO21T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO19") {
 //     console.log("GPIO19 toggle");
      socket.emit("GPIO19T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO2") {
//     console.log("GPIO2 toggle");
      socket.emit("GPIO2T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO3") {
 //     console.log("GPIO3 toggle");
      socket.emit("GPIO3T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO17") {
 //     console.log("GPIO17 toggle");
      socket.emit("GPIO17T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO27") {
 //     console.log("GPIO27 toggle");
      socket.emit("GPIO27T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO23") {
 //     console.log("GPIO23 toggle");
      socket.emit("GPIO23T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO24") {
 //     console.log("GPIO24 toggle");
      socket.emit("GPIO24T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO7") {
 //     console.log("GPIO7 toggle");
      socket.emit("GPIO7T");  // send GPIO button toggle to node.js server
      
    } else if (x === "GPIO8") {
 //     console.log("GPIO8 toggle");
      socket.emit("GPIO8T");  // send GPIO button toggle to node.js server
      
    }
  }
  
  if (e.target.id === "GPIO26M") {
 //   console.log("GPIO26 pressed");
    socket.emit("GPIO26", 0); 
    document.getElementById('GPIO26').checked = 0;
    
  } else if (e.target.id === "GPIO20M") {
    console.log("GPIO20 pressed");
    socket.emit("GPIO20", 0); 
    document.getElementById('GPIO20').checked = 0;
    
  } else if (e.target.id === "GPIO21M") {
//    console.log("GPIO21 pressed");
    socket.emit("GPIO21", 0); 
    document.getElementById('GPIO21').checked = 0;
    
  } else if (e.target.id === "GPIO19M") {
//    console.log("GPIO19 pressed");
    socket.emit("GPIO19", 0); 
    document.getElementById('GPIO19').checked = 0;
    
  } else if (e.target.id === "GPIO2M") {
//    console.log("GPIO2 pressed");
    socket.emit("GPIO2", 0); 
    document.getElementById('GPIO2').checked = 0;
    
  } else if (e.target.id === "GPIO3M") {
//    console.log("GPIO3 pressed");
    socket.emit("GPIO3", 0); 
    document.getElementById('GPIO3').checked = 0;
    
  } else if (e.target.id === "GPIO17M") {
//    console.log("GPIO17 pressed");
    socket.emit("GPIO17", 0); 
    document.getElementById('GPIO17').checked = 0;
    
  } else if (e.target.id === "GPIO27M") {
//    console.log("GPIO27 pressed");
    socket.emit("GPIO27", 0); 
    document.getElementById('GPIO27').checked = 0;
    
  } else if (e.target.id === "GPIO23M") {
//    console.log("GPIO23 pressed");
    socket.emit("GPIO23", 0); 
    document.getElementById('GPIO23').checked = 0;
    
  } else if (e.target.id === "GPIO24M") {
//    console.log("GPIO24 pressed");
    socket.emit("GPIO24", 0); 
    document.getElementById('GPIO24').checked = 0;
    
  } else if (e.target.id === "GPIO8M") {
//    console.log("GPIO8 pressed");
    socket.emit("GPIO8", 0); 
    document.getElementById('GPIO8').checked = 0;
    
  } else if (e.target.id === "GPIO7M") {
//    console.log("GPIO7 pressed");
    socket.emit("GPIO7", 0); 
    document.getElementById('GPIO7').checked = 0;
    
  }
}


function ReportMouseUp(e) {
  if (e.target.id === "GPIO26M") {
    socket.emit("GPIO26", 1); 
    document.getElementById('GPIO26').checked = 1;
    
  } else if (e.target.id === "GPIO20M") {
    socket.emit("GPIO20", 1); 
    document.getElementById('GPIO20').checked = 1;
    
  } else if (e.target.id === "GPIO21M") {
    socket.emit("GPIO21", 1); 
    document.getElementById('GPIO21').checked = 1;
    
  } else if (e.target.id === "GPIO19M") {
    socket.emit("GPIO19", 1); 
    document.getElementById('GPIO19').checked = 1;
    
  } else if (e.target.id === "GPIO2M") {
    socket.emit("GPIO2", 1); 
    document.getElementById('GPIO2').checked = 1;
    
  } else if (e.target.id === "GPIO3M") {
    socket.emit("GPIO3", 1); 
    document.getElementById('GPIO3').checked = 1;
    
  } else if (e.target.id === "GPIO17M") {
    socket.emit("GPIO17", 1); 
    document.getElementById('GPIO17').checked = 1;
    
  } else if (e.target.id === "GPIO27M") {
    socket.emit("GPIO27", 1); 
    document.getElementById('GPIO27').checked = 1;
    
  } else if (e.target.id === "GPIO23M") {
    socket.emit("GPIO23", 1); 
    document.getElementById('GPIO23').checked = 1;
    
  } else if (e.target.id === "GPIO24M") {
    socket.emit("GPIO24", 1); 
    document.getElementById('GPIO24').checked = 1;
  
  } else if (e.target.id === "GPIO7M") {
    socket.emit("GPIO7", 1); 
    document.getElementById('GPIO7').checked = 1;
    
  } else if (e.target.id === "GPIO8M") {
    socket.emit("GPIO8", 1); 
    document.getElementById('GPIO8').checked = 1;
  }
}

function TouchMove(e) {

}



/** function to sense if device is a mobile device ***/
// Reference: https://stackoverflow.com/questions/11381673/detecting-a-mobile-browser

var isMobile = {
  Android: function() {
      return navigator.userAgent.match(/Android/i);
  },
  BlackBerry: function() {
      return navigator.userAgent.match(/BlackBerry/i);
  },
  iOS: function() {
      return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  Opera: function() {
      return navigator.userAgent.match(/Opera Mini/i);
  },
  Windows: function() {
      return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
  },
  any: function() {
      return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
  }
};


