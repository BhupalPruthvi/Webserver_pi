var http = require('http').createServer(handler); //require http server, and create server with function handler()
var fs = require('fs'); //require filesystem module
var url = require('url');
var path = require('path');
var io = require('socket.io','net')(http) //require socket.io module and pass the http object (server)
var Gpio = require('onoff').Gpio; //include onoff to interact with the GPIO
var LED26 = new Gpio(26, 'out'); //use GPIO pin 26 as output
var LED20 = new Gpio(20, 'out'); //use GPIO pin 20 as output
var LED21 = new Gpio(21, 'out'); //use GPIO pin 21 as output
var LED19 = new Gpio(19, 'out'); //use GPIO pin 19 as output
var LED2 = new Gpio(2, 'out'); //use GPIO pin 2 as output
var LED3 = new Gpio(3, 'out'); //use GPIO pin 3 as output
var LED23 = new Gpio(23, 'out'); //use GPIO pin 23 as output
var LED24 = new Gpio(24, 'out'); //use GPIO pin 24 as output
var LED27 = new Gpio(27, 'out'); //use GPIO pin 27 as output
var LED17 = new Gpio(17, 'out'); //use GPIO pin 17 as output
var LED7 = new Gpio(7, 'out'); //use GPIO pin 27 as output
var LED8 = new Gpio(8, 'out'); //use GPIO pin 17 as output

var GPIO26value = 1;  // Turn on the LED by default
var GPIO20value = 1;  // Turn on the LED by default
var GPIO21value = 1;  // Turn on the LED by default
var GPIO19value = 1;  // Turn on the LED by default
var GPIO2value = 1;  // Turn on the LED by default
var GPIO3value = 1;  // Turn on the LED by default
var GPIO27value = 1;  // Turn on the LED by default
var GPIO17value = 1;  // Turn on the LED by default
var GPIO24value = 1;  // Turn on the LED by default
var GPIO23value = 1;  // Turn on the LED by default
var GPIO7value = 1;  // Turn on the LED by default
var GPIO8value = 1;  // Turn on the LED by default
/****** CONSTANTS******************************************************/

const WebPort = 80;


/* if you want to run WebPort on a port lower than 1024 without running
 * node as root, you need to run following from a terminal on the pi
 * sudo apt update
 * sudo apt install libcap2-bin
 * sudo setcap cap_net_bind_service=+ep /usr/local/bin/node
 */
 
/*************** Web Browser Communication ****************************/



// Start http webserver
http.listen(WebPort, function() {  // This gets call when the web server is first started.
	LED26.writeSync(GPIO26value); //turn LED on or off
	LED20.writeSync(GPIO20value); //turn LED on or off
	LED21.writeSync(GPIO21value); //turn LED on or off
	LED19.writeSync(GPIO19value); //turn LED on or off
	LED2.writeSync(GPIO2value); //turn LED on or off
	LED3.writeSync(GPIO3value); //turn LED on or off
	LED27.writeSync(GPIO27value); //turn LED on or off
	LED17.writeSync(GPIO17value); //turn LED on or off
	LED23.writeSync(GPIO23value); //turn LED on or off
	LED24.writeSync(GPIO24value); //turn LED on or off
	LED7.writeSync(GPIO7value); //turn LED on or off
	LED8.writeSync(GPIO8value); //turn LED on or off
	console.log('Server running on Port '+WebPort);
	console.log('FBKHRN3	Main_RST	GPIO21 = '+GPIO21value);
	console.log('FBKHRN3	ConnectPhone	GPIO20 = '+GPIO20value);
	
	console.log('8BKHRN3	Main_RST	GPIO26 = '+GPIO26value);
	console.log('8BKHRN3	ConnectPhone	GPIO19 = '+GPIO19value);
	
	console.log('2CKHRN3	Main_RST	GPIO02 = '+GPIO2value);
	console.log('2CKHRN3	ConnectPhone	GPIO03 = '+GPIO3value);
	
	console.log('1BKHRN3	Main_RST	GPIO17 = '+GPIO17value);
	console.log('1BKHRN3	ConnectPhone	GPIO27 = '+GPIO27value);
	
	console.log('4BKHRN3	Main_RST	GPIO23 = '+GPIO23value);
	console.log('4BKHRN3	ConnectPhone	GPIO24 = '+GPIO24value);
	
	console.log('HBKHRN3	Main_RST	GPIO07 = '+GPIO7value);
	console.log('HBKHRN3	ConnectPhone	GPIO08 = '+GPIO8value);
	} 
); 



// function handler is called whenever a client makes an http request to the server
// such as requesting a web page.
function handler (req, res) { 
    var q = url.parse(req.url, true);
    var filename = "." + q.pathname;
    console.log('filename='+filename);
    var extname = path.extname(filename);
    if (filename=='./') {
      console.log('retrieving default index.html file');
      filename= './index.html';
    }
    
    // Initial content type
    var contentType = 'text/html';
    
    // Check ext and set content type
    switch(extname) {
	case '.js':
	    contentType = 'text/javascript';
	    break;
	case '.css':
	    contentType = 'text/css';
	    break;
	case '.json':
	    contentType = 'application/json';
	    break;
	case '.png':
	    contentType = 'image/png';
	    break;
	case '.jpg':
	    contentType = 'image/jpg';
	    break;
	case '.ico':
	    contentType = 'image/png';
	    break;
    }
    

    
    fs.readFile(__dirname + '/public/' + filename, function(err, content) {
	if(err) {
	    console.log('File not found. Filename='+filename);
	    fs.readFile(__dirname + '/public/404.html', function(err, content) {
		res.writeHead(200, {'Content-Type': 'text/html'}); 
		return res.end(content,'utf8'); //display 404 on error
	    });
	}
	else {
	    // Success
	    res.writeHead(200, {'Content-Type': contentType}); 
	    return res.end(content,'utf8');
	}
      
    });
}


// Execute this when web server is terminated
process.on('SIGINT', function () { //on ctrl+c
  LED26.writeSync(1); // Turn LED off
  LED26.unexport(); // Unexport LED GPIO to free resources
  
  LED20.writeSync(1); // Turn LED off
  LED20.unexport(); // Unexport LED GPIO to free resources
  
  LED21.writeSync(1); // Turn LED off
  LED21.unexport(); // Unexport LED GPIO to free resources
  
  LED19.writeSync(1); // Turn LED off
  LED19.unexport(); // Unexport LED GPIO to free resources
    
  LED2.writeSync(1); // Turn LED off
  LED2.unexport(); // Unexport LED GPIO to free resources
  
  LED3.writeSync(1); // Turn LED off
  LED3.unexport(); // Unexport LED GPIO to free resources
  
  LED27.writeSync(1); // Turn LED off
  LED27.unexport(); // Unexport LED GPIO to free resources
  
  LED17.writeSync(1); // Turn LED off
  LED17.unexport(); // Unexport LED GPIO to free resources
  
  LED23.writeSync(1); // Turn LED off
  LED23.unexport(); // Unexport LED GPIO to free resources
  
  LED24.writeSync(1); // Turn LED off
  LED24.unexport(); // Unexport LED GPIO to free resources
  
  LED7.writeSync(1); // Turn LED off
  LED7.unexport(); // Unexport LED GPIO to free resources
  
  LED8.writeSync(1); // Turn LED off
  LED8.unexport(); // Unexport LED GPIO to free resources
  
  process.exit(); //exit completely
}); 


/****** io.socket is the websocket connection to the client's browser********/

io.sockets.on('connection', function (socket) {// WebSocket Connection
    console.log('A new client has connected. Send LED status');
    socket.emit('GPIO26', GPIO26value);
    socket.emit('GPIO20', GPIO20value);
    socket.emit('GPIO21', GPIO21value);
    socket.emit('GPIO19', GPIO19value);
    socket.emit('GPIO2', GPIO2value);
    socket.emit('GPIO3', GPIO3value);
    socket.emit('GPIO27', GPIO27value);
    socket.emit('GPIO17', GPIO17value);
    socket.emit('GPIO23', GPIO23value);
    socket.emit('GPIO24', GPIO24value);
    socket.emit('GPIO7', GPIO7value);
    socket.emit('GPIO8', GPIO8value);

    // this gets called whenever client presses GPIO26 toggle light button
    socket.on('GPIO26T', function(data) { 
	if (GPIO26value) GPIO26value = 0;
	else GPIO26value = 1;
	console.log('new GPIO26 value='+GPIO26value);
	LED26.writeSync(GPIO26value); //turn LED on or off
	console.log('Send new GPIO26 state to ALL clients');
	io.emit('GPIO26', GPIO26value); //send button status to ALL clients 
    });
    
	// this gets called whenever client presses GPIO21 toggle light button
    socket.on('GPIO3T', function(data) { 
	if (GPIO3value) GPIO3value = 0;
	else GPIO3value = 1;
	console.log('new GPIO3 value='+GPIO3value);
	LED3.writeSync(GPIO3value); //turn LED on or off
	console.log('Send new GPIO3 state to ALL clients');
	io.emit('GPIO3', GPIO3value); //send button status to ALL clients 	
	});

	/*

    // this gets called whenever client presses GPIO20 toggle light button
    socket.on('GPIO20T', function(data) { 
	if (GPIO20value) GPIO20value = 0;
	else GPIO20value = 1;
	console.log('new GPIO20 value='+GPIO20value);
	LED20.writeSync(GPIO20value); //turn LED on or off
	console.log('Send new GPIO20 state to ALL clients');
	io.emit('GPIO20', GPIO20value); //send button status to ALL clients 
    });
    
    // this gets called whenever client presses GPIO21 toggle light button
    socket.on('GPIO21T', function(data) { 
	if (GPIO21value) GPIO21value = 0;
	else GPIO21value = 1;
	console.log('new GPIO21 value='+GPIO21value);
	LED21.writeSync(GPIO21value); //turn LED on or off
	console.log('Send new GPIO21 state to ALL clients');
	io.emit('GPIO21', GPIO21value); //send button status to ALL clients 	
    });
    
    // this gets called whenever client presses GPIO16 toggle light button
    socket.on('GPIO19T', function(data) { 
	if (GPIO19value) GPIO19value = 0;
	else GPIO19value = 1;
	console.log('new GPIO19 value='+GPIO19value);
	LED19.writeSync(GPIO19value); //turn LED on or off
	console.log('Send new GPIO19 state to ALL clients');
	io.emit('GPIO19', GPIO19value); //send button status to ALL clients 	
    });

    
    socket.on('GPIO27T', function(data) { 
	if (GPIO27value) GPIO27value = 0;
	else GPIO27value = 1;
	console.log('new GPIO27 value='+GPIO27value);
	LED26.writeSync(GPIO27value); //turn LED on or off
	console.log('Send new GPIO27 state to ALL clients');
	io.emit('GPIO27', GPIO27value); //send button status to ALL clients 
    });
    
    // this gets called whenever client presses GPIO20 toggle light button
    socket.on('GPIO17T', function(data) { 
	if (GPIO17value) GPIO17value = 0;
	else GPIO17value = 1;
	console.log('new GPIO17 value='+GPIO17value);
	LED17.writeSync(GPIO17value); //turn LED on or off
	console.log('Send new GPIO17 state to ALL clients');
	io.emit('GPIO17', GPIO17value); //send button status to ALL clients 
    });
    
    
    
    // this gets called whenever client presses GPIO16 toggle light button
    socket.on('GPIO3T', function(data) { 
	if (GPIO3value) GPIO3value = 0;
	else GPIO3value = 1;
	console.log('new GPIO3 value='+GPIO3value);
	LED3.writeSync(GPIO3value); //turn LED on or off
	console.log('Send new GPIO3 state to ALL clients');
	io.emit('GPIO3', GPIO3value); //send button status to ALL clients 	
    });
    
    socket.on('GPIO23T', function(data) { 
	if (GPIO23value) GPIO23value = 0;
	else GPIO23value = 1;
	console.log('new GPIO23 value='+GPIO23value);
	LED23.writeSync(GPIO23value); //turn LED on or off
	console.log('Send new GPIO23 state to ALL clients');
	io.emit('GPIO23', GPIO23value); //send button status to ALL clients 	
    });
    
    // this gets called whenever client presses GPIO16 toggle light button
    socket.on('GPIO24T', function(data) { 
	if (GPIO24value) GPIO24value = 0;
	else GPIO24value = 1;
	console.log('new GPIO24 value='+GPIO24value);
	LED24.writeSync(GPIO24value); //turn LED on or off
	console.log('Send new GPIO24 state to ALL clients');
	io.emit('GPIO24', GPIO24value); //send button status to ALL clients 	
    });
*/
    //-----------------------------------------------------------------------
    // this gets called whenever client presses GPIO20 momentary light button
    socket.on('GPIO26', function(data) { 
	GPIO26value = data;
	if (GPIO26value != LED26.readSync()) { //only change LED if status has changed
	    LED26.writeSync(GPIO26value); //turn LED on or off
	    console.log('8BKHRN3	Main_RST	GPIO26:	'+GPIO26value);
	    io.emit('GPIO26', GPIO26value); //send button status to ALL clients 
	};

    });
    
    // this gets called whenever client presses GPIO21 momentary light button
    socket.on('GPIO21', function(data) { 
	GPIO21value = data;
	if (GPIO21value != LED21.readSync()) { //only change LED if status has changed
	    LED21.writeSync(GPIO21value); //turn LED on or off
	    console.log('FBKHRN3	Main_RST	GPIO21: '+GPIO21value);
	    io.emit('GPIO21', GPIO21value); //send button status to ALL clients e
	};

    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO19', function(data) { 
	GPIO19value = data;
	if (GPIO19value != LED19.readSync()) { //only change LED if status has changed
	    LED19.writeSync(GPIO19value); //turn LED on or off
	    console.log('8BKHRN3	ConnectPhone	GPIO19:	'+GPIO19value);
	    io.emit('GPIO19', GPIO19value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO20', function(data) { 
	GPIO20value = data;
	if (GPIO20value != LED20.readSync()) { //only change LED if status has changed
	    LED20.writeSync(GPIO20value); //turn LED on or off
	    console.log('FBKHRN3	ConnectPhone	GPIO20: '+GPIO20value);
	    io.emit('GPIO20', GPIO20value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO20 momentary light button
    socket.on('GPIO2', function(data) { 
	GPIO2value = data;
	if (GPIO2value != LED2.readSync()) { //only change LED if status has changed
	    LED2.writeSync(GPIO2value); //turn LED on or off
	    console.log('2CKHRN3	Main_RST	GPIO02: '+GPIO2value);
	    io.emit('GPIO2', GPIO2value); //send button status to ALL clients 
	};

    });
    
    // this gets called whenever client presses GPIO21 momentary light button
    socket.on('GPIO3', function(data) { 
	GPIO3value = data;
	if (GPIO3value != LED3.readSync()) { //only change LED if status has changed
	    LED3.writeSync(GPIO3value); //turn LED on or off
	    console.log('2CKHRN3	ConnectPhone	GPIO03: '+GPIO3value);
	    io.emit('GPIO3', GPIO3value); //send button status to ALL clients e
	};

    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO23', function(data) { 
	GPIO23value = data;
	if (GPIO23value != LED23.readSync()) { //only change LED if status has changed
	    LED23.writeSync(GPIO23value); //turn LED on or off
	    console.log('4BKHRN3	Main_RST	GPIO23: '+GPIO23value);
	    io.emit('GPIO23', GPIO23value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO24', function(data) { 
	GPIO24value = data;
	if (GPIO24value != LED24.readSync()) { //only change LED if status has changed
	    LED24.writeSync(GPIO24value); //turn LED on or off
	    console.log('4BKHRN3	ConnectPhone	GPIO24: '+GPIO24value);
	    io.emit('GPIO24', GPIO24value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO27', function(data) { 
	GPIO27value = data;
	if (GPIO27value != LED27.readSync()) { //only change LED if status has changed
	    LED27.writeSync(GPIO27value); //turn LED on or off
	    console.log('1BKHRN3	ConnectPhone	GPIO27: '+GPIO27value);
	    io.emit('GPIO27', GPIO27value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO17', function(data) { 
	GPIO17value = data;
	if (GPIO17value != LED17.readSync()) { //only change LED if status has changed
	    LED17.writeSync(GPIO17value); //turn LED on or off
	    console.log('1BKHRN3	Main_RST	GPIO17: '+GPIO17value);
	    io.emit('GPIO17', GPIO17value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO7', function(data) { 
	GPIO7value = data;
	if (GPIO7value != LED7.readSync()) { //only change LED if status has changed
	    LED7.writeSync(GPIO7value); //turn LED on or off
	    console.log('HBKHRN3	Main_RST	GPIO7: '+GPIO7value);
	    io.emit('GPIO7', GPIO7value); //send button status to ALL clients 
	};
	
    });
    
    // this gets called whenever client presses GPIO16 momentary light button
    socket.on('GPIO8', function(data) { 
	GPIO8value = data;
	if (GPIO8value != LED8.readSync()) { //only change LED if status has changed
	    LED8.writeSync(GPIO8value); //turn LED on or off
	    console.log('HBKHRN3	ConnectPhone	GPIO8: '+GPIO8value);
	    io.emit('GPIO8', GPIO8value); //send button status to ALL clients 
	};
	
    });
 
 

    //Whenever someone disconnects this piece of code executed
    socket.on('disconnect', function () {
	console.log('A user disconnected');
    });
    

}); 


 



